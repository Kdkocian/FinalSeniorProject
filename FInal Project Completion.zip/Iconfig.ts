export interface Iconfig {
    domainName: string;
    certificateArn: string;
}