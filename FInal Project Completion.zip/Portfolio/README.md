## Project Description /Background/OverView
The purpose of this project/application is to allow for user set their schedules on a calendar provided to them. The problem was to create a web-based application for users to have the ability to build a schedule for themselves. The calendar would then allow for the user to select dates and set events on the calendar. The events would then be highlighted on the calendar for the user to view. 

The web-based application is being deployed on AWS as the application must be flexable while also being secure useing cloudfront provided by AWS. Using AWS allows for redeployment if there are errors with the application. AWS was also chosen for its Cloudfront, Cognito, Route53, S3, API-Gateway, and RDS (Relational Database Service).  

The back-end of the application was developed useing dotnet and C#. The choice of this programming language was chosen for its use in object oriented programming. Each event on the calendar is an object which would allow for the user to set their events per date.

The front-end of the application was built with typescript and React. React allows for leverage static web-hosting, integration with web-api's, and easy integration with AWS-cognito. This allows for us to have a secure connection while also have options for integration.

Video Link [Final Senior Project](https://youtu.be/jT1kfQISJs0)

## Design Diagrams
### ![FinalClassDiagram](FinalClassDiagram.png)
### ![FinalFlowDiagram](FinalFlow.png)
### ![FinalUMLDiagram](FinalUMLDiagram.png)
# Code Snippets

In the Methodize.ts file we have a small code snippet:
 new MethodizeStack(app, 'MethodizeStack', { });
 This code will allow the application to be allows the cdk to deploy on AWS and allows the application to run.

  in the lib directory we have several .ts files that all handle the deployment of the application. 

  Our Source Directory we have our API folder. This folder houses the data for the backend of the application. It has such methods as the AllDates method which will showcase all the dates on the calendar and the events that lie on them. 

  ex: 
  public List<CalendarEventModel> AllDates()
        {
            List<CalendarEventModel> foundDates = new List<CalendarEventModel>();

            //SQL statement
            string sqlStatement = "SELET * FROM dbo.events";
            //string sqlStatement = "SELECT * FROM Calendar.Events";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(sqlStatement, connection);

                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        foundDates.Add(new CalendarEventModel(
                            (DateTime)reader[1],
                            (DateTime)reader[2],
                            (DateTime)reader[3],
                            (DateTime)reader[4],
                            (DateTime)reader[5],
                            (int)reader[6],
                            (int)reader[7],
                            (string)reader[8],
                            (string)reader[9],
                            (int)reader[10],
                            (string)reader[11]));
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
            Console.WriteLine(foundDates);
            return foundDates;
 Within the Source Api folder there are other methods such as the AllDates method which all handle back-end functionality for the application. 

# Supporting Artifacts
Scrum Chart - Milestone Final Burndown Chat
Testing/updated program data - week 3 final.docx
