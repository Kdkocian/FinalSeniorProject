import { RemovalPolicy } from 'aws-cdk-lib';
import { Construct } from 'constructs';
import { Bucket, BlockPublicAccess, HttpMethods } from 'aws-cdk-lib/aws-s3';
import { PolicyStatement, AnyPrincipal, Effect } from 'aws-cdk-lib/aws-iam';
import { UserPool, OAuthScope } from 'aws-cdk-lib/aws-cognito';
import { Distribution, GeoRestriction, PriceClass, OriginAccessIdentity, OriginRequestPolicy, ViewerProtocolPolicy, ResponseHeadersPolicy, CachePolicy, AllowedMethods } from 'aws-cdk-lib/aws-cloudfront';
import { S3Origin } from 'aws-cdk-lib/aws-cloudfront-origins';
import { Certificate } from 'aws-cdk-lib/aws-certificatemanager';


export interface iUiResourceProps {
    domainName: string;
    certificateArn: string;
}

/*creates a bucket s3bucket to host on cloudfront  */
export class UiResources extends Construct {
    public readonly uiBucket: Bucket;
    public readonly uiDistribution: Distribution;

    constructor( scope: Construct, id: string, props : iUiResourceProps){
        super( scope, id);

        this.uiBucket = new Bucket(this, 'ruiBucket', {
            websiteIndexDocument: 'index.html',
            websiteErrorDocument: 'index.html',
            removalPolicy: RemovalPolicy.DESTROY,
            blockPublicAccess: BlockPublicAccess.BLOCK_ALL
          });
             //import the cert to enable https     
            const cert = Certificate.fromCertificateArn(this, 'domainCert', props.certificateArn); 
            
            const originAccess = new OriginAccessIdentity(this, 'OAI');
            this.uiBucket.grantReadWrite(originAccess);

            this.uiBucket.addCorsRule({
              allowedMethods: [HttpMethods.GET],
              allowedOrigins: ["*"],
              allowedHeaders: ["*"],
              exposedHeaders: ["Access-Control-Allow-Origin"]
            })

            this.uiDistribution = new Distribution(this, 'uiDistribution', { 
              defaultRootObject: 'index.html',
              defaultBehavior: {
                origin: new S3Origin(this.uiBucket, {originAccessIdentity: originAccess}),
                originRequestPolicy: OriginRequestPolicy.CORS_S3_ORIGIN,
                viewerProtocolPolicy: ViewerProtocolPolicy.REDIRECT_TO_HTTPS,
                responseHeadersPolicy: ResponseHeadersPolicy.CORS_ALLOW_ALL_ORIGINS,
                cachePolicy: CachePolicy.CACHING_OPTIMIZED,
                allowedMethods: AllowedMethods.ALLOW_ALL
              },
              domainNames: [ props.domainName ],
              geoRestriction: GeoRestriction.allowlist('US'),
              priceClass: PriceClass.PRICE_CLASS_100,
              certificate: cert,
              enableLogging: true
            });
            

          //create user pool


          //TODO setup Cognito
          // const pool = new UserPool(this, 'Pool');
          // pool.addClient('app-client', {
          //   oAuth: {
          //     flows: {
          //       authorizationCodeGrant: true,
          //     },
          //     scopes: [ OAuthScope.OPENID ],
          //     callbackUrls: [ `${this.uiBucket.bucketWebsiteUrl}` ],
          //     logoutUrls: [ `${this.uiBucket.bucketWebsiteUrl}` ],
          //   },
          // });
    }
}