import { Construct } from "constructs";

export interface IAppLayer{

}

export class Applayer extends Construct {
    constructor( scope: Construct, id: string, props: IAppLayer){
        super(scope, id);
    }
}