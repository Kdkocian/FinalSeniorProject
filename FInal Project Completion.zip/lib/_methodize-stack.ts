import * as cdk from 'aws-cdk-lib';
import { Construct } from 'constructs';
import { UiResources } from './uiResources';
import { Database } from './database';
import { Applayer } from './app-Layer';
import { config } from '../config';


export class MethodizeStack extends cdk.Stack {
  constructor(scope: Construct, id: string, props?: cdk.StackProps) {
    super(scope, id, props);

    //Create UI in cognito
    const ui = new UiResources(this, 'UI', { domainName: config.domainName, certificateArn: config.certificateArn });

    //Create databases
    const database = new Database(this, 'Database');

    //Create the Api

    //this will authenticate against cognito and use

    //This will have a reference to database for dates/times
    const appLayer = new Applayer(this, 'AppLayer', {});
  }
}
