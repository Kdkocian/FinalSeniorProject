import { Construct } from "constructs";

export interface IDatabase{

}

export class Database extends Construct {
    constructor( scope: Construct, id: string, props?: IDatabase){
        super(scope, id);
    }
}