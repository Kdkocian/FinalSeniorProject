import React from 'react';
import Demo from './Demo';

function App(){
    return(
        <Demo />
    );
}

export default App;