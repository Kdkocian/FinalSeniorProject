﻿using API.Model;
using API.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Methodize.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CalendarController : ControllerBase
    {
        public ICalendarEventService repository { get; set; }

        public CalendarController(ICalendarEventService dataservice)
        {
            repository = dataservice;
        }

        [HttpGet]
        [Route("Index")]
        public IActionResult Index()
        {
            //List<CalendarModel> calendarList = repository.AllDates();
            return new JsonResult(repository.AllDates());
        }

        //TODO Setup calendar
        [HttpGet]
        [Route("Calendar")]
        public IActionResult Calendar()
        {

            return new JsonResult("hello from calendar"); //may not need this method
        }

        //TODO SETup EventHandler

        public IActionResult EventHandlerCalendar()
        {
            return new JsonResult("Hello from EventHandler"); //need to figureout eventhandler
        }

        //TODO CREATE EVENT
        [HttpPost]
        [Route("Create")]
        public IActionResult CreateEvent(CalendarEventTemplateModel evnt)
        {
            return new JsonResult(repository.CreateEventByDate(evnt)); //for testing
        }
        [HttpPost]
        [Route("Update")]
        public IActionResult HandleUpdateCalendar(int id, CalendarEventTemplateModel evnt)
        {
            return new JsonResult(repository.UpdateEventById(id, evnt)); //for testing
        }

        [HttpGet]
        [Route("GetId")]
        public IActionResult GetEventById(int id)
        {
            return new JsonResult(repository.GetEventById(id));
        }

        [HttpGet]
        [Route("GetDate")]
        public IActionResult GetEventByDate(DateTime date)
        {
            return new JsonResult(repository.GeteventsByDate(date));
        }
        //TODO SETUP DELETE EVENT
        public IActionResult DeleteEventById(int eventId)
        {
            CalendarEventModel evnt = repository.GetEventById(eventId);
            if (evnt != null)
            {
                bool success = repository.Delete(eventId);

                if (success == true)
                {
                    return new JsonResult("Index", repository.AllDates());
                }
                else
                {
                    return new JsonResult("Index", repository.AllDates());
                }
            }
            return new JsonResult(repository.AllDates());
        }
    }
}
