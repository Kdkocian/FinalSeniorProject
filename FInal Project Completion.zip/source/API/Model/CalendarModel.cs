﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace API.Model
{
    public class CalendarModel
    {
        public DateTime date { get; set; }
        public DateTime time { get; set; }

        public CalendarModel(DateTime date, DateTime time)
        {
            this.date = date;
            this.time = time;
        }
    }
}
