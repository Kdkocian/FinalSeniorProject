using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace API.Model
{
    public class CalendarEventTemplateModel
    {
        public int id { get; set; }
        public string title { get; set; }
        public string description { get; set; }
        public int type { get; set; }
        public string sourceType { get; set; }
        public DateTime createdAt { get; set; }
        public DateTime updatedAt { get; set; }
        public DateTime scheduledAt { get; set; }
        public DateTime triggeredAt { get; set; }
        public string content { get; set; }

        public CalendarEventTemplateModel (int id, string title, string description, int type, string sourceType, DateTime createdAt, DateTime updatedAt, string content)
        {
            this.id = id;
            this.title = title;
            this.description = description;
            this.type = type;
            this.sourceType = sourceType;
            this.createdAt = createdAt;
            this.updatedAt = updatedAt;
            this.content = content;
        }
    }
}