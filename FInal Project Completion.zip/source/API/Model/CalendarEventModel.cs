using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace API.Model
{
    public class CalendarEventModel
    {
        public DateTime date { get; set; }
        public DateTime createdTime { get; set; }
        public DateTime updatedTime { get; set; }
        public DateTime scheduleTime { get; set; }
        public DateTime triggeredTime { get; set; }
        public int userId { get; set; }
        public int eventId { get; set; }
        public string eventTitle { get; set; }
        public string eventDescription { get; set; }
        public string content { get; set; }

        public CalendarEventModel(DateTime date, DateTime createdAt, DateTime updatedAt, DateTime scheduleTime, DateTime triggeredTime, int userId, 
        int eventId, string eventTitle, string eventDescription, int type, string content)
        {
            this.date = date;
            this.createdTime = createdAt;
            this.updatedTime = updatedAt;
            this.scheduleTime = scheduleTime;
            this.triggeredTime = triggeredTime;
            this.userId = userId;
            this.eventId = eventId;
            this.eventTitle = eventTitle;
            this.eventDescription = eventDescription;
            this.content = content;
        }
    }
}