using System.Globalization;
using API.Model;
using System;
using System.Collections.Generic;

namespace API.Services
{
    public interface ICalendarEventService
    {
        List<CalendarEventModel> AllDates(); //list all dates

        CalendarEventModel CreateEventByDate(CalendarEventTemplateModel evnt); //Create an event by date/time

        CalendarEventModel GetEventById(int id); //Gets events by Id;

        CalendarEventModel GeteventsByDate(DateTime date); //gets events by date

        CalendarEventModel UpdateEventById(int id, CalendarEventTemplateModel evnt); //updates an event by Id

        bool Delete(int eventId); //deletes an event by Id
    }
}