using API.Model;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace API.Services
{
    public class CalendarEventDAO : ICalendarEventService
    {
        string connectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Calendar;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
        //string connectionString = "server=127.0.0.1; uid=root; pwd=; database=seniorproject"; //connection string
        public List<CalendarEventModel> AllDates()
        {
            List<CalendarEventModel> foundDates = new List<CalendarEventModel>();

            //SQL statement
            string sqlStatement = "SELET * FROM dbo.events";
            //string sqlStatement = "SELECT * FROM Calendar.Events";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(sqlStatement, connection);

                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        foundDates.Add(new CalendarEventModel(
                            (DateTime)reader[1],
                            (DateTime)reader[2],
                            (DateTime)reader[3],
                            (DateTime)reader[4],
                            (DateTime)reader[5],
                            (int)reader[6],
                            (int)reader[7],
                            (string)reader[8],
                            (string)reader[9],
                            (int)reader[10],
                            (string)reader[11]));
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
            Console.WriteLine(foundDates);
            return foundDates;
        }

        public CalendarEventModel CreateEventByDate(CalendarEventTemplateModel evnt)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string sqlStatement = "INSERT INTO `event`(`title`, `description`, `type`, `createdAt`, `updatedAt`, `scheduledAt`, `triggeredAt`, `content`) " +
                    "VALUES ('@Title','@Description','@Type','@createdAt','@UpdatedAt','@schduledAt', '@triggeredAt','@content')"; //TODO finish sql statement

                SqlCommand command = new SqlCommand(sqlStatement, connection);

                command.Parameters.AddWithValue("@Title", evnt.title);
                command.Parameters.AddWithValue("@Description", evnt.description);
                command.Parameters.AddWithValue("@Type", evnt.type);
                command.Parameters.AddWithValue("@createdAt", evnt.createdAt);
                command.Parameters.AddWithValue("@updatedAt", evnt.updatedAt);
                command.Parameters.AddWithValue("@scheduledAt", evnt.scheduledAt);
                command.Parameters.AddWithValue("@triggeredAt", evnt.triggeredAt);
                command.Parameters.AddWithValue("@content", evnt.content);

                try
                {
                    connection.Open();
                    command.ExecuteNonQuery();
                    Console.WriteLine("Successful creation of Event");
                }
                catch(Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
            return null;
        }

        public bool DeleteEventByid(int eventId)
        {
            bool deleted = false;
            string sqlStatement = "DELETE FROM Calendar.Event WHERE ID = " + eventId;

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(sqlStatement, connection);

                    //get Id of event for deletion
                    //input id for SqlQuery
                    command.Parameters.AddWithValue("@ID", eventId);
                    connection.Open();
                    if (command.ExecuteNonQuery() > 0)
                    {
                        deleted = true;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return deleted;
        }

        public CalendarEventModel GetEventById(int id)
        {
            CalendarEventModel foundEvent = null;

            string sqlStatement = "SELECT id FROM Calendar.Event WHERE id =" + id;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(sqlStatement, connection);

                command.Parameters.AddWithValue("@Id", id);

                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        foundEvent = new CalendarEventModel
                        (
                            (DateTime)reader[1],
                            (DateTime)reader[2],
                            (DateTime)reader[3],
                            (DateTime)reader[4],
                            (DateTime)reader[5],
                            (int)reader[6],
                            (int)reader[7],
                            (string)reader[8],
                            (string)reader[9],
                            (int)reader[10],
                            (string)reader[11]
                        );
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                };
            }
            return foundEvent;
        }

        public CalendarEventModel GeteventsByDate(DateTime date)
        {
            CalendarEventModel foundEvent = null;

            string sqlStatement = "SELECT date FROM Calendar.Event WHERE ScheduledAt = @date";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(sqlStatement, connection);

                command.Parameters.AddWithValue("@date", date);

                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        foundEvent = new CalendarEventModel
                        (
                            (DateTime)reader[1],
                            (DateTime)reader[2],
                            (DateTime)reader[3],
                            (DateTime)reader[4],
                            (DateTime)reader[5],
                            (int)reader[6],
                            (int)reader[7],
                            (string)reader[8],
                            (string)reader[9],
                            (int)reader[10],
                            (string)reader[11]
                        );
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                };
            }
            return foundEvent;
        }

        public CalendarEventModel UpdateEventById(int id, CalendarEventTemplateModel evnt)
        {

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string sqlStatement = "UPDATE Calendar.Event SET title = @Title, description = @Description, updatedAt = @updatedAt, scheduledAt = @scheduledAt, content = @content WHERE id = @id"; 

                SqlCommand command = new SqlCommand(sqlStatement, connection);

                command.Parameters.AddWithValue("@Title", evnt.title);
                command.Parameters.AddWithValue("@Description", evnt.description);
                command.Parameters.AddWithValue("@Type", evnt.type);
                command.Parameters.AddWithValue("@createdAt", evnt.createdAt);
                command.Parameters.AddWithValue("@updatedAt", evnt.updatedAt);
                command.Parameters.AddWithValue("@scheduledAt", evnt.scheduledAt);
                command.Parameters.AddWithValue("@triggeredAt", evnt.triggeredAt);
                command.Parameters.AddWithValue("@content", evnt.content);

                try
                    {
                        connection.Open();              
                        Console.WriteLine("Successfull Update of Event");
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                    };
            }
            return null;
        }
    }
}