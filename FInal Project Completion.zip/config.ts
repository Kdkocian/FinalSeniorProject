import { Iconfig } from "./Iconfig";


export const config : Iconfig = {
    domainName: 'justmethodize.com',
    certificateArn: 'arn:aws:acm:us-east-1:089149208915:certificate/6a450d54-af5c-4038-a50f-cb7e1483fac0'
}